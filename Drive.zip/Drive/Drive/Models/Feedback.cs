﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Drive.Models
{
    public class Feedback
    {
        [Key]
        public string feed { get; set; }
        public string naam { get; set; }
    }
}
