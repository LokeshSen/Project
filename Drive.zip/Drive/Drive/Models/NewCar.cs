﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Drive.Models
{
    public class NewCar
    {
        [Key]
        public int NewCarid { get; set; }
        public int Model { get; set; }

        public int Engine { get; set; }
        public int seat { get; set; }
        public int mileage { get; set; }
        public string color { get; set; }


    }
}
