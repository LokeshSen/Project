﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Drive.Models;

namespace Drive.Models
{
    public class DataDbContext:DbContext
    {
        public DataDbContext(DbContextOptions<DataDbContext> options) : base(options)
        {



        }
        public DbSet<User> User { get; set; }
        public DbSet<NewCar> NewCar { get; set; }
        public DbSet<UsedCar> UsedCar { get; set; }
        public DbSet<CategoryUsedCar> CategoryUsedCar { get; set; }
        public DbSet<Feedback> Feedback { get; set; }

        public DbSet<CategoryNewCar> CategoryNewCar { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<User>().HasData(new User
            {
                id = 1,
                name = "Diksha",
                Email = "diksha@gmail.com",
                Address = "12/24",
                Occupation = "student",
                Gender = "Female"
            });
            modelBuilder.Entity<User>().HasData(new User
            {
                id = 2,
                name = "Xceedance",
                Email = "xceed@gmail.com",
                Address = "45/5",
                Occupation = "Employee",
                Gender = "Female"
            });
            modelBuilder.Entity<User>().HasData(new User
            {
                id = 3,
                name = "Xceed",
                Email = "xc@gmail.com",
                Address = "13/85",
                Occupation = "Business",
                Gender = "male"
            });




            modelBuilder.Entity<NewCar>().HasData(new NewCar
            {
                NewCarid = 1,
                Model = 858,

                Engine = 5858,
                seat = 4,
                mileage = 546,
                color = "Blue"



            });
            modelBuilder.Entity<NewCar>().HasData(new NewCar
            {
                NewCarid = 2,
                Model = 858,

                Engine = 5858,
                seat = 4,
                mileage = 546,
                color = "Blue"



            });
            modelBuilder.Entity<NewCar>().HasData(new NewCar
            {
                NewCarid = 3,
                Model = 123,

                Engine = 8569,
                seat = 6,
                mileage = 546,
                color = "Red"



            });
            modelBuilder.Entity<NewCar>().HasData(new NewCar
            {
                NewCarid = 4,

                Engine = 7898,
                seat = 5,
                mileage = 858,
                color = "Black"



            });



            modelBuilder.Entity<UsedCar>().HasData(new UsedCar
            {
                UsedCarid = 1,

                Model = "hyundai",
                Engine = 5858,
                seat = 4,
                color = "Blue",
                MeterReading = 98562
            });
            modelBuilder.Entity<UsedCar>().HasData(new UsedCar
            {
                UsedCarid = 2,



                Model = "hyundai",
                Engine = 9632,
                seat = 4,
                color = "Red",
                MeterReading = 47576
            });
            modelBuilder.Entity<UsedCar>().HasData(new UsedCar
            {
                UsedCarid = 3,



                Model = "Volkswagen",
                Engine = 1498,
                seat = 6,
                color = "BLack",
                MeterReading = 1482
            });
            modelBuilder.Entity<CategoryUsedCar>().HasData(new CategoryUsedCar
            {
                CategoryUsedCarId = 1,
                Brand = "Hyundai"
            });
            modelBuilder.Entity<CategoryUsedCar>().HasData(new CategoryUsedCar
            {
                CategoryUsedCarId = 2,
                Brand = "Volkswagen"
            });
            modelBuilder.Entity<CategoryUsedCar>().HasData(new CategoryUsedCar
            {
                CategoryUsedCarId = 3,
                Brand = "Audi"
            });
            modelBuilder.Entity<Feedback>().HasData(new Feedback
            {
                feed="Please help us improve more",
                naam="Hey"
            });
            modelBuilder.Entity<CategoryNewCar>().HasData(new CategoryNewCar
            {
                Price = 300000,
                Brand = "Audi"
            });
            modelBuilder.Entity<CategoryNewCar>().HasData(new CategoryNewCar
            {
                Price = 1500000,
                Brand = "MG"
            });



        }



       
    }
}
