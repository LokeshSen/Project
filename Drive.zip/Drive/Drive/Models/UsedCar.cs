﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Drive.Models
{
    public class UsedCar
    {
        [Key]
        public int UsedCarid { get; set; }

        public int Year { get; set; }
        public string Model { get; set; }
        public int Engine { get; set; }
        public int seat { get; set; }
        public int MeterReading { get; set; }
        public string color { get; set; }
    }
}
