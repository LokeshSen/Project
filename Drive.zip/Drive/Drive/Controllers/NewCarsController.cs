﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Drive.Models;

namespace Drive.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NewCarsController : ControllerBase
    {
        private readonly DataDbContext _context;

        public NewCarsController(DataDbContext context)
        {
            _context = context;
        }

        // GET: api/NewCars
        [HttpGet]
        public async Task<ActionResult<IEnumerable<NewCar>>> GetNewCar()
        {
            return await _context.NewCar.ToListAsync();
        }

        // GET: api/NewCars/5
        [HttpGet("{id}")]
        public async Task<ActionResult<NewCar>> GetNewCar(int id)
        {
            var newCar = await _context.NewCar.FindAsync(id);

            if (newCar == null)
            {
                return NotFound();
            }

            return newCar;
        }

        // PUT: api/NewCars/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutNewCar(int id, NewCar newCar)
        {
            if (id != newCar.NewCarid)
            {
                return BadRequest();
            }

            _context.Entry(newCar).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!NewCarExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/NewCars
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<NewCar>> PostNewCar(NewCar newCar)
        {
            _context.NewCar.Add(newCar);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetNewCar", new { id = newCar.NewCarid }, newCar);
        }

        // DELETE: api/NewCars/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<NewCar>> DeleteNewCar(int id)
        {
            var newCar = await _context.NewCar.FindAsync(id);
            if (newCar == null)
            {
                return NotFound();
            }

            _context.NewCar.Remove(newCar);
            await _context.SaveChangesAsync();

            return newCar;
        }

        private bool NewCarExists(int id)
        {
            return _context.NewCar.Any(e => e.NewCarid == id);
        }
    }
}
