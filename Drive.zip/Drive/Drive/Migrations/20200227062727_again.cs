﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Drive.Migrations
{
    public partial class again : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "CategoryNewCar",
                columns: new[] { "Price", "Brand" },
                values: new object[] { 300000, "Audi" });

            migrationBuilder.InsertData(
                table: "CategoryNewCar",
                columns: new[] { "Price", "Brand" },
                values: new object[] { 1500000, "MG" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "CategoryNewCar",
                keyColumn: "Price",
                keyValue: 300000);

            migrationBuilder.DeleteData(
                table: "CategoryNewCar",
                keyColumn: "Price",
                keyValue: 1500000);
        }
    }
}
